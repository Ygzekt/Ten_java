package javastudy;

public class HelloMyJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//sysout 적고 ctrl space
		//실행은 ctrl f11
		//이거때문에 c수업하다 java수업하면 맨날 헷갈림
		System.out.println("Hello World");

	}

}
