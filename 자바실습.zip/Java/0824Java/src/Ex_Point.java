import java.util.Scanner;

//두 클래스를 상속관계로 포함
class Point{ 
	//위치 정보 포함 x,y좌표
	private int x;
	private int y;
	public Point(int a, int b) {
		this.x=a;
		this.y=b;
	}
	
	//x좌표와 y좌표값을 반환하는 get() 함수
	public int getX() {return this.x;}
	public int getY() {return this.y;}
	public void print() {
		//Point 클래스의 객체에 의해 호출될때 실행됨
		System.out.println("x좌표: "+this.x);
		System.out.println("y좌표: "+this.y);
	}
}

class ColorPoint extends Point{ 
	//위치정보,색상포함
	private String color;
	public ColorPoint(int a,int b,String s) {
		super(a,b); //부모클래스의 생성자 통해 위치 정보 초기화
		this.color=s;
	}
	public void print() {
		//Point 클래스의 객체에 의해 호출될때 실행됨
		//<오버라이딩> 
		//부모 클래스의 함수 중 형태가 같은 함수가 있을 시
		//자신의 클래스에 있는 함수를 우선시하여 실행함
		System.out.println("x좌표: "+this.getX());
		System.out.println("y좌표: "+this.getY());
		System.out.println("색상: "+this.color);
	}
}


public class Ex_Point{
	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		//객체 2개생성
		int x1=s.nextInt();
		int y1=s.nextInt();
		Point p1=new Point(x1,y1);
	
		
		int x2=s.nextInt();
		int y2=s.nextInt();
		String color=s.next();
		ColorPoint p2=new ColorPoint(x2,y2,color);
		System.out.println();
		
		p1.print();		
		System.out.println();
		p2.print();
	}
}