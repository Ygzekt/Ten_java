import java.util.Scanner;

public class JavaClass {
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		System.out.print("줄바꿈을 하지 않는다.");
		System.out.println("자동 줄바꿈을 한다.");
		System.out.println(); //줄바꿈만 한다.
		
		int year=2022;
		System.out.println("지금은 "+year+"년 입니다.");
		
		String name=s.next(); //공백있는 문자열
		int age=s.nextInt(); //정수
		boolean gender=s.nextBoolean(); //true, false
		double height=s.nextDouble(); //실수
		char blood=s.next().charAt(0); //문자 1개
		s.nextLine(); //입력 씹힘 방지
		String mood=s.nextLine();
		
		System.out.println("이름: "+name);
		System.out.println("나이: "+age);
		System.out.println("혈액형: "+blood);
		System.out.println("기분: "+mood);
		
		//bool형
		
		boolean result=(1+2!=3);
		if (result==true)
		{
			System.out.println("옳은 식 입니다.");
		}
		else
			System.out.println("틀린 식 입니다.");
		
		System.out.println();
		
		//배열 :: 정적할당, 동적할당
		
		int arr1[]=new int [5]; //정적할당
		
		int num=5;
		int arr2[]=new int[num]; //동적할당
		
		// 두 사람 이름 입력: 내 이름이랑 옆 사람 이름
		String mine="LeeYuNa";
		String yours="KimHyeMin";
		System.out.println("내 이름은 "+mine);
		System.out.println("네 이름은 "+yours);
		
		//첫 글자 비교는 charAt()로
		
		if(mine.charAt(0)==yours.charAt(0))
		{
			System.out.println("첫 글자가 같다.");
		}
		else
			System.out.println("첫 글자가 다르다.");
		
		// toCharArray() :: String형 -> Char형
		// 첫번째 문자 대문자->소문자, 소문자->대문자
		
		/* 정수와 문자 간에 수학적 연산을 수행할 때 
		 * 오버플로가 발생할 수 있습니다. 이는 해당 값이 문자에 할당되기 
		 * 때문에 예상 결과에 영향을 미칠 수 있습니다.
		 * 
		 * invr[len1++] = str[i]-32;
		 * 
		 * 하지만 다음과 같이 char로 캐스팅해야 합니다.
		 * 
		 * invr[len1++] = (char)(str[i]-32);*/
		
		
		char m[]=mine.toCharArray();
		char y[]=yours.toCharArray(); //한 문자로 변형해서 비교?
		
		if (m[0]>='A'&&m[0]<='Z')
		{
			m[0]=(char)(m[0]+32); //문자와 정수의 계산이라서 (char)
		}
		else
			m[0]=(char)(m[0]-32);
		
		if (y[0]>='A'&&y[0]<='Z')
		{
			y[0]=(char)(y[0]+32);
		}
		else
			y[0]=(char)(y[0]-32);
		
		//length() :: String 길이를 반환.
		System.out.println("내 이름의 길이는 "+mine.length());
		System.out.println("네 이름의 길이는 "+yours.length());
		
		//equals()
		/*JAVA] == equals 차이

equals 메소드는 비교하고자 하는 대상의 내용 자체를 비교하지만,
== 연산자는 비교하고자 하는 대상의 주소값을 비교합니다.

이는 Call By Reference, Call By Value에 
대한 공부를 하시면 이해할 수 있는 부분입니다.

 CBV(Call By Value를 줄여부르도록 하겠습니당.) 
 는 기본적으로 대상에 주소값을 가지지 않는 것으로 값을 
 할당받는 형태로 사용됩니다. 예를 들어 int, float, 
 double, byte 등 primitive type에 해당됩니다.

 CBR(Call By Reference를 편의상 줄여부릅니다.) 
 는 대상을 선언했을 때, 주소값이 부여됩니다.그래서 어떠한 
 객체를 불러왔을 때는 그 주소값을 불러온다고 봅니다. 이에는 
 Class, Object(객체)가 해당됩니다.

== >> 주소값을 비교
equals >>실질적인 대상의 내용을 비교

++ Tip : equals 의 반대는!?!!?
바로  if(!string.equlas("문자열")ex ) 
if(!str1.equals("AA"))
{System.out.println("AA가 아닙니다");}*/
		
		String mine1="LYN";
		System.out.println("<mine과 mine1은 동일하다.>는 "+(mine==mine1));
		String mine2=s.next();
		System.out.println("내 이름을 다시 입력 해 보세요.");
		System.out.println("<mine1과 mine2는 동일이하.>는 "+(mine1==mine2));
		System.out.println("equals 함수 사용하면?");
		System.out.println("<mine과 mine2는 동일하다.>는 "+(mine.equals(mine2)));
		
		System.out.println();
		
		//do-while() :: 우선 한 번은 무조건 실행 후 조건만족여부 확인
		//for문, while문 :: 특정 조건문을 만족해야 실행 가능
		
		
		
		
		
	}

}
