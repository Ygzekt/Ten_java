/*import java.util.Scanner;

//point 클래스 (위치정보포함)
//멤버변수 : x좌표, y좌표 (private로)
class Point
{
	private int x;
	private int y;
	public Point(int x, int y)
	{
		this.x=x;
		this.y=y;
		System.out.println("클래스 Point의 멤버 x 값 저장 완료");
		System.out.println("저장된 x의 값: "+x);
		System.out.println("클래스 Point의 멤버 y 값 저장 완료");
		System.out.println("저장된 y의 값: "+y);
	}
}

//ColorPoint 클래스 (위치정보, 색상정보 포함)
//멤버변수 : x좌표, y좌표, 색상(private로 할 것)
//**두 클래스는 상속관계로 할 것

class ColorPoint extends Point
{
	private String color;
	public ColorPoint(int x, int y, String c)
	{
		super(x,y);
		this.color=c;
		System.out.println("클래스 ColorPoint의 멤버 c 값 저장 완료");
		System.out.println("저장된 c의 값: "+c);
	}
}

public class quiz {
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		int i=s.nextInt();
		int k=s.nextInt();
		Point p=new Point(i,k);
		
		int j=s.nextInt();
		ColorPoint cp=new ColorPoint(i,k,j);
	}

}*/


//===========================================================================================

import java.util.Scanner;

//두 클래스를 상속 관계로 포함
class Point{ //위치 정보 포함 (x좌표, y좌표)
//Point 클래스 = 부모클래스	
	private int x; //멤버변수 2가지 = 매개변수도 2가지 ->a, b에 넣는다
	private int y;
	public Point(int a, int b) { //멤버 변수 값 초기화 (생성자??)
		this.x=a;
		this.y=b;
	}
	//x좌표와 y좌표의 값을 반환하는 get함수
	public int getX() {return this.x;}
	public int getY() {return this.y;}
	public void print() //프린트(출력)하는거라 반환할 값이 없다 //Point 클래스의 객체에 의해 호출될 때 실행됨.
	{
		//x좌표 y좌표 위치 정보 출력
		System.out.println("x좌표: "+this.x);
		System.out.println("y좌표: "+this.y);
	}
	//private는 자기자신 밖에선 출력불가. 상속받은 클래스에서도 출력불가
}

class ColorPoint extends Point { //위치 정보, 색상 포함 (x/y좌표, 색상) 상속 받아오므로 매개변수3개
	//ColorPoint클래스 = 자식클래스
	private String color;
	public ColorPoint(int a, int b, String s) { //super를 통해서 생성자 받아와야 함.
		super(a,b); //부모클래스의 생성자 통해서 위치정보를 초기화
		this.color=s;
	}
	
	
	
	public void print() //프린트(출력)하는거라 반환할 값이 없다 //ColorPoint 클래스의 객체에 의해 호출될 때 실행됨.
	// 부모 클래스의 함수 중 형태가 같은 함수가 있을 시 자신의 클래스에 있는 함수를 우선시하여 실행함 (오버라이딩 발생)
	{
		System.out.println("x좌표: "+this.getX());
		System.out.println("y좌표: "+this.getY()); //private라서 바로 못 가져오니 get함수로.
		System.out.println("색상 "+this.color); //내 클래스거니까 바로 가져올 수 있음.
		
	}
}

public class quiz{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		//객체 2개 생성
		System.out.print("점1에 대한 정보(x,y);");		
		int x1=s.nextInt(); //p1 객체 생성 위한 x좌표 입력
		int y1=s.nextInt(); //p1 객체 생성 위한 y좌표 입력
		Point p1=new Point(x1, y1); //Point 클래스의 p1 생성
		
		System.out.print("점2에 대한 정보(x,y,color):");
		int x2=s.nextInt(); //p2 객체 생성 위한 x좌표 입력
		int y2=s.nextInt(); //p2 객체 생성 위한 y좌표 입력
		String color=s.next(); //p2 객체 생성 위한 색상 문자열 입력  //문자열은 한 줄 다 받아야하니 next
		ColorPoint p2=new ColorPoint(x2, y2, color); //ColorPoint 클래스의 p2 생성
		System.out.println();
		
		p1.print(); //Point  클래스의 print()가 실행
		System.out.println();
		p2.print(); //ColorPoint 클래스의 print()가 실행
	}
}