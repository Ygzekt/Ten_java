package bj;

class Person1{
	private String name;
	private int age;
	
	
	public Person1(String n, int a)
	{
		this.name=n;
		this.age=a;
	}
	public String getName() {return this.name);
}


class student1 extends Person1{
	private String school;
	
	public Student1(string n, int a, String s)
	{
		super(n, a);
		this.school=s;
	}
	public void print() 
	{
		System.out.println("학생 정보");
		System.out.println("이름: "+this.getName);
		System.out.println("나이: "+this.getAge);
		System.out.println("소속: "+this.school);
		
	}
}

class Teacher1 extends Person1{
	private String company;
	
	
	public Teacher1(String n, int a, String c)
	{
		super(n, a);
		this.company=c;
	}
	public void print() 
	{
		System.out.println("교사 정보");
		System.out.println("이름: "+this.getName);
		System.out.println("나이: "+this.getAge);
		System.out.println("소속: "+this.company);
	}
}

public class Ex_stu {
	public static void main(String[] args)
	{
		Student1 stu=new Student1("이유나",24,"KB");
		Teacher1 t=new Teacher1("이유나",24,"KB");
		
		stu.print();
		System.out.println();	// 구분
		t.print();
	}

}
