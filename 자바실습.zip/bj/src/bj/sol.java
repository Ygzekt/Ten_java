package bj;

/*import java.util.*;

public class sol 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		int sum=s.nextInt();
		String str=s.nextLine();
		
		while(true)
		{
			if(str.equals("=")) //입력받은 문자열 내용이 =와 같다면
				break;
			switch (str)
			{
			case "+":
				sum +=s.nextInt();
				break;
			case "-":
				sum -=s.nextInt();
				break;
			case "*":
				sum *=s.nextInt();
				break;
			case "/":
				sum /=s.nextInt();
				break;
			default:
				break;
			}
		}
		System.out.println(sum);
		s.close();
	}
}




public class sol
{
	public static void main(String[] args)
	{
		//do-while문 및 switch문 사용
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();//첫번째 숫자 입력받기
		do
		{
			char c=s.next().charAt(0); //연산자
			if(c=='=') {break;}
			int b=s.nextInt(); //두 번째 숫자 입력받기
			switch(c)
			{
			case '+':
				a+=b;
				break;
			case '-':
				a-=b;
				break;
			case '*':
				a*=b;
				break;
			case '/':
				a/=b;
				break;
			case '%':
				a%=b;
				break;
			}
		}
		while(true);
		
		System.out.println(a);
			}
	}*/


//첫 번째 숫자가 두 번째 숫자의 약수이다.
//첫 번째 숫자가 두 번째 숫자의 배수이다.
//첫 번째 숫자가 두 번째 숫자의 약수와 배수 모두 아니다.

import java.util.*;

public class sol
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		while(true)
		{
			int a=s.nextInt();
			int b=s.nextInt();
			
			if (a==0&&b==0)
			{
				break;
			}
			
			if (a == b)
			{
				break;
			}
			else if (b % a == 0)
			{
				System.out.println("factor");
				break;
			}
			else if (a % b == 0)
			{
				System.out.println("multiple");
				break;
			}
			else
				System.out.println("neither");
			    break;
		}
		
	}
}