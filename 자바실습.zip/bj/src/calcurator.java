import java.util.Scanner;

/*public class calcurator {

	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("첫번째 숫자를 입력하세요");
		String str1 = scan.nextLine();
		
		System.out.println("사칙연산 기호중 하나를 입력하세요");
		String op = scan.nextLine();
		
		System.out.println("두번째 숫자를 입력하세요");
		String str2 = scan.nextLine();
		
		int num1 = Integer.parseInt(str1);
		int num2 = Integer.parseInt(str2);
		int num3;
		
		if(op.equals("+")) {
			num3 = num1 + num2;
		}
		else if(op.equals("-")) {
			num3 = num1 - num2;
		}
		else if(op.equals("/")) {
			num3 = num1 / num2;
		}
		else{
			num3 = num1 * num2;
		}
		
		System.out.println(str1 + op + str2 + "=" + num3);
	}

}*/



class Cal{
	//멤버변수 선언부
	private char c; //멤버 변수는 하나만 하는게 조건
	
	//생성자 선언부
	public Cal(char c) {
		this.
	}
	
	public char getCh() {return this.ch;}
	public int sum(int a, int b) {return a+b;}
	public int sub(int a, int b) {return a-b;}
	public int mul(int a, int b) {return a*b;}
	public int div(int a, int b) {return a/b;}
	public int rest(int a,int b) {return a%b;}
}

public class Ex_Cal{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Cal arr[]=new Cal[5];
		arr[0]=new Cal('+');
		arr[0]=new Cal('-');
		arr[0]=new Cal('*');
		arr[0]=new Cal('/');
		arr[0]=new Cal('%');  //객체 생성 완료
		
		
		//반복문을 사용하여 계산기 프로그램 만들기
		//숫자 2개가 0 0 입력받을 시 반목문 종료
		//-> 무한 생선문 생성	
		while(true) {
			//숫자 2개, 연산자 순으로 입력
			int a=s.nextInt();//숫자입력
			int b=s.nextInt();
			char c=s.next().charAt(0); //연산자 
			if(a==0&&b==0)
			{
				break;
			}

			int result; //결과 저장
			if (c==arr[0].getCh()) {result=arr[0].sum(a,b);}
			else if(c==arr[1].getCh()) {result=arr[1].sub(a,b);}
			else if(c==arr[2].getCh()) {result=arr[2].mul(a,b);}
			else if(c==arr[3].getCh()) {result=arr[3].div(a,b);}
			else if(c==arr[4].getCh()) {result=arr[4].rest(a,b);}
			
			
			System.out.println("결과는 "+result);
		}
	
	}
}
