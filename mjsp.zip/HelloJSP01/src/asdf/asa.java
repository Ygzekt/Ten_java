package asdf;

public class asa {
private String name;
private int age;
private String Id;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getId() {
	return Id;
}
public void setId(String id) {
	Id = id;
}
public asa(String name, int age, String id) {
	super();
	this.name = name;
	this.age = age;
	Id = id;
}

@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "�̸� : "+name+" ���� : "+age+" ���̵� : " +Id;
	}
}
