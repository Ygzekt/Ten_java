package Mytest.myjava;

public class Customer {
	private String name;
	private int age;
	private String id;
	//��Ʈ ����Ʈ s�� oŰ
	public Customer(String name, int age, String id) {
		super();
		this.name = name;
		this.age = age;
		this.id = id;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "�̸� :"+name+", ���� : "+age+", ���̵� : "+id;
	}
	public boolean isAdult(int limit) {
		if(limit>age)
			return false;
		else
			return true;
	}
	public boolean isAdmin(String admin)
	{
		if(this.id.equals(admin))
			return true;
		else
			return false;
	}
}
