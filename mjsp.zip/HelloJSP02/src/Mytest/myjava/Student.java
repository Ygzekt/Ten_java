package Mytest.myjava;

public class Student {

	private String name;
	private String pw;
	private String hobbys;
	private String protocol;
	private String Major;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getHobbys() {
		return hobbys;
	}
	public void setHobbys(String[] hobbys) {
		this.hobbys = "";
		for(int i=0; i<hobbys.length;i++)
		{
			switch(hobbys[i])
			{
			case "cook":
				this.hobbys+="�丮";
				break;
			case "run":
				this.hobbys+="�޸���";
				break;
			case "swim":
				this.hobbys+="����";
				break;
			case "sleep":
				this.hobbys+="���ڱ�";
				break;
			}
			if(i!=hobbys.length-1)
				this.hobbys+=",";
		}
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getMajor() {
		return Major;
	}
	public void setMajor(String major) {
		//Major = major;
		if(major.equals("eng"))
			this.Major= "����";
		else if(major.equals("math"))
			this.Major= "����";
		else if(major.equals("kor"))
			this.Major="����";
		else
			this.Major="����";	
	}
	
	
	
}
